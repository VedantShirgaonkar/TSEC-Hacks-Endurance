# Endurance Dashboard - Feature Specifications

## Dashboard Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  ENDURANCE                               🔔 Alerts  👤 Admin  ⚙️ Settings   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐            │
│  │ Real-Time   │ │ Compliance  │ │ Audit       │ │ Human       │            │
│  │ Monitoring  │ │ Reports     │ │ Trail       │ │ Evaluation  │            │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘            │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                        MAIN CONTENT AREA                            │    │
│  │                                                                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Feature 1: Real-Time Monitoring Dashboard

### 1.1 Overall Health Score
```
┌─────────────────────────────────────────────────┐
│           TODAY'S AI HEALTH                     │
│                                                 │
│              ┌───────────┐                      │
│              │    86     │  ← Large gauge       │
│              │   /100    │                      │
│              └───────────┘                      │
│                                                 │
│   ▲ 3% from yesterday    📊 View Trend         │
└─────────────────────────────────────────────────┘
```

### 1.2 Dimension Scores (8 Cards)
```
┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
│ Bias &      │ │ Data        │ │ Explain-    │ │ Ethical     │
│ Fairness    │ │ Grounding   │ │ ability     │ │ Alignment   │
│     88      │ │     94      │ │     90      │ │     92      │
│     ━━━━    │ │     ━━━━━   │ │     ━━━━━   │ │     ━━━━━   │
└─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘
┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
│ Human       │ │ Legal       │ │ Security    │ │ Response    │
│ Control     │ │ Compliance  │ │             │ │ Quality     │
│     85      │ │     96      │ │     83      │ │     89      │
│     ━━━━    │ │     ━━━━━━  │ │     ━━━     │ │     ━━━━    │
└─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘
```

### 1.3 Live Query Feed
```
┌─────────────────────────────────────────────────────────────────┐
│  LIVE QUERIES                                    ⏸️ Pause       │
├─────────────────────────────────────────────────────────────────┤
│  12:05:32  "What was IT expenditure..."      Score: 86  ✅      │
│  12:05:28  "List all approved vendors..."    Score: 91  ✅      │
│  12:05:15  "Provide employee count..."       Score: 45  ⚠️      │
│  12:04:58  "What is the budget for..."       Score: 23  ❌      │
│  ...                                                            │
└─────────────────────────────────────────────────────────────────┘
```

### 1.4 Alert Summary
```
┌─────────────────────────────────────────────────┐
│  🚨 ACTIVE ALERTS                               │
├─────────────────────────────────────────────────┤
│  ⚠️ 3 Hallucinations detected in last hour     │
│  ⚠️ 1 RTI compliance violation                  │
│  ✅ Security metrics stable                     │
│  ✅ Drift detection: No anomalies               │
└─────────────────────────────────────────────────┘
```

---

## Feature 2: Human Evaluation Loops

### 2.1 Evaluation Queue
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  PENDING HUMAN EVALUATIONS                              Filter: All ▾      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  Query: "What was the IT expenditure in FY 2022-23?"                   │ │
│  │  Response: "The Department spent ₹18.6 crore on IT consultants..."     │ │
│  │  Auto Score: 86/100    Flagged: Needs human verification               │ │
│  │  ┌─────────────────┐                                                   │ │
│  │  │ EVALUATE NOW    │                                                   │ │
│  │  └─────────────────┘                                                   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  Query: "List all policy changes in 2023..."                           │ │
│  │  Response: "The major policy changes include..."                       │ │
│  │  Auto Score: 45/100    Flagged: Low confidence                         │ │
│  │  ┌─────────────────┐                                                   │ │
│  │  │ EVALUATE NOW    │                                                   │ │
│  │  └─────────────────┘                                                   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Evaluation Form
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HUMAN EVALUATION                                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  QUERY                                                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ "What was the IT expenditure in FY 2022-23?"                           │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  AI RESPONSE                                                                 │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ "The Department spent ₹18.6 crore on IT consultants. Vendors: ABC     │ │
│  │ Technologies, National Informatics, DataCore Solutions."              │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  SOURCE DOCUMENTS (RAG)                                                      │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ 📄 FinancialStatement_2023.pdf - Section 4.1                          │ │
│  │ 📄 ProcurementRegister.xlsx - Rows 22-45                              │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                              │
│  RATE THE RESPONSE                                                           │
│                                                                              │
│  Accuracy          ○ ○ ○ ○ ○                                               │
│                    1 2 3 4 5                                                │
│                                                                              │
│  Completeness      ○ ○ ○ ○ ○                                               │
│                    1 2 3 4 5                                                │
│                                                                              │
│  Source Citation   ○ ○ ○ ○ ○                                               │
│                    1 2 3 4 5                                                │
│                                                                              │
│  Clarity           ○ ○ ○ ○ ○                                               │
│                    1 2 3 4 5                                                │
│                                                                              │
│  Any Issues Found?                                                           │
│  ☐ Hallucination   ☐ Missing info   ☐ Wrong source   ☐ Privacy concern    │
│                                                                              │
│  Comments                                                                    │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                                                                        │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐                                        │
│  │   APPROVE    │  │   REJECT     │                                        │
│  └──────────────┘  └──────────────┘                                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.3 Feedback Integration
- Human scores **adjust** machine scores (weighted average)
- Disagreements flagged for review
- Feedback loops back to improve thresholds

---

## Feature 3: Reasoning Breakdown

### 3.1 Claim-by-Claim Verification View
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  RESPONSE VERIFICATION BREAKDOWN                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Response Text (hover to highlight claims):                                  │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ "Based on the Annual Financial Statement, the total expenditure was   │ │
│  │  [₹18.6 crore]₁. Vendors: [ABC Technologies]₂, [National Informatics]₃│ │
│  │  and [DataCore Solutions]₄. [Director Sharma]₅ oversaw the project."  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  CLAIM VERIFICATION TABLE                                                    │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  #  │ Claim                  │ Source Match           │ Status         │ │
│  │─────┼────────────────────────┼────────────────────────┼────────────────│ │
│  │  1  │ ₹18.6 crore            │ FinStatement:4.1       │ ✅ VERIFIED    │ │
│  │  2  │ ABC Technologies       │ ProcRegister:Row22     │ ✅ VERIFIED    │ │
│  │  3  │ National Informatics   │ ProcRegister:Row23     │ ✅ VERIFIED    │ │
│  │  4  │ DataCore Solutions     │ ProcRegister:Row24     │ ✅ VERIFIED    │ │
│  │  5  │ Director Sharma        │ NO MATCH               │ ❌ HALLUCINATE │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  VERIFICATION SUMMARY                                                        │
│  Verified: 4/5 (80%)  |  Hallucinated: 1/5 (20%)  |  Score: 76/100          │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Source Document Viewer
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  SOURCE DOCUMENT: FinancialStatement_2023.pdf                    Page 47    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Section 4.1: IT Consultancy Expenditure                                     │
│  ──────────────────────────────────────────                                 │
│  [HIGHLIGHTED] Total expenditure on external IT consultants: ₹18.6 crore    │
│                                                                              │
│  Breakdown by vendor:                                                        │
│  • ABC Technologies Pvt Ltd: ₹8.2 crore                                     │
│  • National Informatics Services: ₹6.1 crore                                │
│  • DataCore Solutions India: ₹4.3 crore                                     │
│                                                                              │
│  ← Previous Page                                        Next Page →         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.3 Metrics Calculation Breakdown
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  METRICS CALCULATION DETAILS                                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  DIMENSION: Data Grounding & Drift                         Score: 94/100    │
│  ───────────────────────────────────────────────────────────────────────    │
│                                                                              │
│  ┌──────────────────────┬──────────────┬────────────────────────────────┐  │
│  │ Metric               │ Raw Value    │ Calculation                    │  │
│  ├──────────────────────┼──────────────┼────────────────────────────────│  │
│  │ Groundedness Score   │ 0.80         │ 4 verified / 5 total claims    │  │
│  │ Source Coverage      │ 0.95         │ 95% of response has citations  │  │
│  │ Hallucination Rate   │ 0.20         │ 1 hallucinated / 5 claims      │  │
│  │ PSI (Drift)          │ 0.06         │ Current vs baseline dist.      │  │
│  └──────────────────────┴──────────────┴────────────────────────────────┘  │
│                                                                              │
│  Aggregation Formula:                                                        │
│  Score = (Groundedness × 0.4) + (Coverage × 0.3) + ((1-Halluc) × 0.2)       │
│        + ((1-PSI) × 0.1) = 0.94 → 94/100                                    │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Feature 4: Audit Log

### 4.1 Timeline View
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  AUDIT TRAIL                    📅 Date Range: Today ▾    🔍 Search         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  12:05:32.001  │  📥 QUERY_RECEIVED                                         │
│                │  Session: sess_abc123                                       │
│                │  Query: "What was the IT expenditure..."                   │
│                │  User: anonymous_user_456                                   │
│                │                                                             │
│  12:05:32.156  │  🔍 RAG_RETRIEVAL                                          │
│                │  Documents: 3                                               │
│                │  Sources: FinStatement.pdf, ProcRegister.xlsx, Policy.pdf │
│                │  Similarity: [0.95, 0.88, 0.72]                            │
│                │                                                             │
│  12:05:33.422  │  🤖 RESPONSE_GENERATED                                     │
│                │  Tokens: 156 (prompt: 1200, completion: 156)               │
│                │  Latency: 1.266s                                           │
│                │  Model: gpt-4-turbo                                        │
│                │                                                             │
│  12:05:33.450  │  🔬 VERIFICATION_STARTED                                   │
│                │  Claims extracted: 5                                       │
│                │                                                             │
│  12:05:33.890  │  ✅ CLAIM_VERIFIED                                         │
│                │  Claim: "₹18.6 crore"                                      │
│                │  Source: FinStatement.pdf:47                               │
│                │  Method: exact_match                                       │
│                │                                                             │
│  12:05:34.120  │  ❌ CLAIM_FLAGGED                                          │
│                │  Claim: "Director Sharma"                                  │
│                │  Status: HALLUCINATION                                     │
│                │  Confidence: 0.92                                          │
│                │                                                             │
│  12:05:34.250  │  📊 SCORE_CALCULATED                                       │
│                │  Overall: 86/100                                           │
│                │  Dimensions: {bias: 88, grounding: 94, ...}                │
│                │                                                             │
│  12:05:45.000  │  👤 HUMAN_FEEDBACK                                         │
│                │  Evaluator: admin@ministry.gov.in                          │
│                │  Rating: 4.2/5                                             │
│                │  Adjusted Score: 87/100                                    │
│                │                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│  📥 Export as JSON    📥 Export as CSV    📥 Compliance Report              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Audit Filtering
- By time range
- By session/user
- By event type
- By score threshold
- By compliance status

### 4.3 Immutability Proof
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  AUDIT ENTRY VERIFICATION                                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Entry ID: audit_2024020412053200001                                        │
│  Timestamp: 2024-02-04T12:05:32.001Z                                        │
│                                                                              │
│  SHA-256 Hash: 7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9│
│  Previous Hash: 3a7bd3e2360a3d29eea436fcfb7e44c735d117c42d1c1835420b6b9942d│
│                                                                              │
│  ✅ Hash Chain Valid - Entry has not been tampered                          │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Feature 5: Compliance Reporting

### 5.1 Compliance Dashboard
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  COMPLIANCE STATUS                                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌───────────────────┐  ┌───────────────────┐  ┌───────────────────┐       │
│  │ RTI ACT           │  │ DPDP ACT          │  │ GDPR              │       │
│  │      97%          │  │      94%          │  │      N/A          │       │
│  │  ━━━━━━━━━━━      │  │  ━━━━━━━━━━       │  │  (Not Applicable) │       │
│  │  ✅ Compliant     │  │  ✅ Compliant     │  │                   │       │
│  └───────────────────┘  └───────────────────┘  └───────────────────┘       │
│                                                                              │
│  RECENT VIOLATIONS                                                          │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  ⚠️ RTI-SEC8-001: Personal data partially disclosed (Session: abc123) │ │
│  │     Time: 12:03:45  |  Status: Under Review  |  Severity: MEDIUM       │ │
│  │                                                                        │ │
│  │  ⚠️ RTI-SOURCE-002: Source citation missing (Session: def456)         │ │
│  │     Time: 11:45:22  |  Status: Resolved  |  Severity: LOW              │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Generate Compliance Report
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  GENERATE COMPLIANCE REPORT                                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Report Type:     ○ Daily Summary                                           │
│                   ○ Weekly Executive Report                                 │
│                   ● Monthly Compliance Audit                                │
│                   ○ Custom Date Range                                       │
│                                                                              │
│  Include Sections:                                                          │
│                   ☑ Executive Summary                                       │
│                   ☑ Metrics by Dimension                                    │
│                   ☑ Violation Details                                       │
│                   ☑ Human Feedback Summary                                  │
│                   ☑ Recommendations                                         │
│                   ☐ Raw Audit Logs (Appendix)                               │
│                                                                              │
│  Format:          ○ PDF    ● HTML    ○ JSON                                │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────┐          │
│  │              GENERATE REPORT                                 │          │
│  └──────────────────────────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Feature 6: Configuration & Settings

### 6.1 Threshold Configuration
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  ALERT THRESHOLDS                                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Overall Score                                                               │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Critical: [__20__]  Warning: [__50__]  Good: [__80__]                  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  Hallucination Rate                                                          │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Max Allowed: [__0.10__]  Alert at: [__0.05__]                          │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  Response Latency                                                            │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Max (ms): [__5000__]  Alert at (ms): [__3000__]                        │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 Dimension Weight Configuration
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  DIMENSION WEIGHTS                                       Profile: Default   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Bias & Fairness         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  15%        │
│  Data Grounding          ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  15%        │
│  Explainability          ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━    12%        │
│  Ethical Alignment       ━━━━━━━━━━━━━━━━━━━━━━━━━━━━          10%        │
│  Human Control           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━          10%        │
│  Legal Compliance        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  18%       │
│  Security                ━━━━━━━━━━━━━━━━━━━━━━━━━━━━          10%        │
│  Response Quality        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━          10%        │
│                                                               ─────         │
│                                                               100%          │
│                                                                              │
│  ┌───────────────────┐  ┌───────────────────┐                              │
│  │   Save Profile    │  │   Reset Default   │                              │
│  └───────────────────┘  └───────────────────┘                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Feature Summary

| Feature | Priority | MVP | Post-Hackathon |
|---------|----------|-----|----------------|
| Real-Time Monitoring | Critical | ✅ | Enhanced |
| Dimension Score Cards | Critical | ✅ | Enhanced |
| Claim Verification View | Critical | ✅ | Enhanced |
| Human Evaluation Form | High | ✅ | Enhanced |
| Audit Timeline | High | ✅ | Enhanced |
| Compliance Dashboard | High | ✅ | Enhanced |
| Source Document Viewer | Medium | Basic | Full PDF viewer |
| Report Generation | Medium | JSON only | PDF/HTML |
| Threshold Config | Medium | Hardcoded | UI Config |
| Weight Config | Low | Hardcoded | UI Config |
